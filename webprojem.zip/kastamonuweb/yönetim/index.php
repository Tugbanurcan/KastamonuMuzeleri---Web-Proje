<form action="login.php" method="POST">
<table align="center">
<tr>
<td>Kullanici Adi</td>
<td>:</td>
<td><input type="text" name="username"></td>
</tr>
<tr>
<td>Sifre</td>
<td>:</td>
<td><input type="password" name="password"></td>
</tr>
<tr>
<td></td>
<td></td>
<td><input type="submit" value="Giris"></td>
</tr>
</table>
</form>